import { createFileRoute } from "@tanstack/react-router";
import {
  ArrowUpRight,
  LayoutDashboard,
  Users,
  Receipt,
  Building2,
  BarChart3,
  Wallet,
  Star,
  Plus,
  Minus,
  ShieldCheck,
  TrendingUp,
  ListChecks,
  UserCog,
} from "lucide-react";
import { useState } from "react";
import dashboardHero from "@/assets/dashboard-hero.png.asset.json";

const FAQS = [
  {
    q: "Is HK Tech built specifically for interior designers?",
    a: "Yes. Unlike generic CRMs, HK Tech is modelled around how interior studios actually run — turnkey and consultation projects, vendor payments, staff profit-sharing, and studio-wide financials in one place.",
  },
  {
    q: "Can I track both turnkey and consultation projects separately?",
    a: "Yes. Project Statistics splits work into Turnkey and Consultation streams so you always see how each side of the studio is performing.",
  },
  {
    q: "Does it show revenue, expenses and net profit in real time?",
    a: "The Business Overview shows Total Revenue, Project Expenses, General Expenses and Net Profit updated live as invoices, bills and payments are recorded.",
  },
  {
    q: "Can I manage my staff, agencies and vendors?",
    a: "Dedicated Agency and Staff modules let you manage partner agencies, in-house team members, roles and profit-sharing — all linked back to the projects they work on.",
  },
  {
    q: "How secure is my studio's data?",
    a: "All data is encrypted in transit and at rest with role-based access, so sensitive financials stay visible only to the people you choose.",
  },
];

const TESTIMONIALS = [
  {
    quote:
      "The Business Overview is the first thing I open every morning. Revenue, expenses and net profit — all in one glance.",
    name: "Ananya Sharma",
    role: "Principal Designer, Studio Nord",
  },
  {
    quote:
      "Splitting turnkey and consultation projects finally gave us clarity on which side of the studio is actually profitable.",
    name: "Rohan Mehta",
    role: "Founder, Casa Verde Interiors",
  },
  {
    quote:
      "Staff profit-sharing used to be a spreadsheet nightmare. Now it's just a module in HK Tech.",
    name: "Priya Nair",
    role: "Operations Lead, Atelier 09",
  },
];

export const Route = createFileRoute("/")({
  component: LandingPage,
  head: () => ({
    meta: [
      { title: "HK Tech — CRM for Interior Designers | Projects, Agency & Studio Financials" },
      {
        name: "description",
        content:
          "HK Tech is the CRM built for interior design studios. Track turnkey and consultation projects, agency & staff, revenue, expenses and net profit in one refined workspace.",
      },
      {
        name: "keywords",
        content:
          "interior designer CRM, interior design studio software, project management for interior designers, studio financials, turnkey projects, HK Tech",
      },
      { property: "og:title", content: "HK Tech — CRM for Interior Designers" },
      {
        property: "og:description",
        content:
          "Run your entire studio — projects, agency, staff and financials — from one thoughtful workspace.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "HK Tech — CRM for Interior Designers" },
      {
        name: "twitter:description",
        content: "The studio CRM built for interior designers.",
      },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "SoftwareApplication",
          name: "HK Tech",
          applicationCategory: "BusinessApplication",
          operatingSystem: "Web",
          description:
            "CRM built for interior design studios. Manage projects, agency, staff and studio financials.",
          aggregateRating: {
            "@type": "AggregateRating",
            ratingValue: "4.9",
            reviewCount: "127",
          },
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: FAQS.map((f) => ({
            "@type": "Question",
            name: f.q,
            acceptedAnswer: { "@type": "Answer", text: f.a },
          })),
        }),
      },
    ],
  }),
});

function LandingPage() {
  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-brand/25">
      <Nav />
      <main>
        <Hero />
        <LogosStrip />
        <Features />
        <Showcase />
        <Testimonials />
        <FAQ />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}

/* ---------- NAV ---------- */
function Nav() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/60 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        <a href="#" className="flex items-center gap-2" aria-label="HK Tech home">
          <div className="grid size-8 place-items-center rounded-lg bg-brand text-brand-foreground">
            <span className="font-display text-sm font-bold">HK</span>
          </div>
          <span className="font-display text-lg font-semibold tracking-tight">HK Tech</span>
        </a>
        <nav className="hidden items-center gap-1 rounded-full border border-border bg-surface px-2 py-1.5 md:flex">
          {[
            ["Features", "#features"],
            ["Workflow", "#workflow"],
            ["Testimonials", "#testimonials"],
            ["FAQ", "#faq"],
          ].map(([label, href]) => (
            <a
              key={label}
              href={href}
              className="rounded-full px-4 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-surface-2 hover:text-foreground"
            >
              {label}
            </a>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <a
            href="https://portal.hktech.in/"
            className="hidden rounded-full px-4 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground sm:inline-flex"
          >
            Log in
          </a>
          <a
            href="https://portal.hktech.in/"
            className="inline-flex items-center gap-1 rounded-full bg-brand px-4 py-2 text-sm font-semibold text-brand-foreground transition-transform hover:scale-[1.02]"
          >
            Try it free
            <ArrowUpRight className="size-4" />
          </a>
        </div>
      </div>
    </header>
  );
}

/* ---------- HERO with floating dashboard ---------- */
function Hero() {
  return (
    <section className="relative overflow-hidden bg-ink text-ink-foreground">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-0 opacity-70"
        style={{
          backgroundImage:
            "radial-gradient(60% 50% at 50% 0%, color-mix(in oklab, var(--brand) 25%, transparent) 0%, transparent 70%)",
        }}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-0 opacity-[0.08]"
        style={{
          backgroundImage:
            "linear-gradient(to right, #fff 1px, transparent 1px), linear-gradient(to bottom, #fff 1px, transparent 1px)",
          backgroundSize: "56px 56px",
          maskImage: "radial-gradient(ellipse at center, black 40%, transparent 75%)",
        }}
      />
      <div className="relative mx-auto max-w-7xl px-6 pt-24 pb-28 text-center sm:pt-32">
        <div className="mx-auto inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs text-white/70 backdrop-blur">
          <span className="size-1.5 rounded-full bg-brand" />
          Trusted by 100+ interior design studios across India
        </div>
        <h1 className="mx-auto mt-6 max-w-4xl text-balance font-display text-5xl font-semibold leading-[1.05] tracking-tight sm:text-7xl">
          The <span className="italic text-brand">CRM</span> for interior designers
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg text-white/70">
          Projects, agency, staff and complete financials — turnkey and consultation, revenue and
          net profit — all in one refined workspace built for design practices.
        </p>

        <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
          <a
            href="https://wa.me/919173774441?text=Hi%20HK%20Tech%2C%20I%20want%20a%20demo%20of%20your%20CRM%20for%20interior%20designers."
            className="inline-flex items-center gap-1 rounded-full bg-brand px-6 py-3 text-sm font-semibold text-brand-foreground transition-transform hover:scale-[1.02]"
          >
            Contact For Demo <ArrowUpRight className="size-4" />
          </a>
        </div>
        <p className="mt-3 text-xs text-white/60">
          14-day free trial · No credit card required
        </p>

        {/* Floating dashboard */}
        <div className="relative mt-20 [perspective:2200px]">
          <div
            aria-hidden
            className="absolute -inset-x-8 -inset-y-8 -z-10 rounded-[2.5rem] bg-[radial-gradient(50%_50%_at_50%_50%,color-mix(in_oklab,var(--brand)_28%,transparent)_0%,transparent_70%)] blur-3xl"
          />
          {/* floating chips */}
          <FloatingChip
            className="left-2 top-8 sm:-left-6 sm:top-14"
            icon={TrendingUp}
            label="Net Profit"
            value="₹42.1L"
            tone="up"
          />
          <FloatingChip
            className="right-2 top-24 sm:-right-8 sm:top-32"
            icon={Wallet}
            label="Total Revenue"
            value="₹1.73 Cr"
            tone="brand"
          />
          <FloatingChip
            className="-bottom-4 left-4 sm:-bottom-6 sm:left-10"
            icon={ListChecks}
            label="Active Projects"
            value="16"
            tone="neutral"
          />

          <div
            className="relative rounded-3xl border border-white/10 bg-white/[0.04] p-2 shadow-[0_60px_120px_-40px_rgba(0,0,0,0.65)] backdrop-blur will-change-transform animate-float-soft"
            style={{ transform: "rotateX(6deg)" }}
          >
            <div className="overflow-hidden rounded-2xl border border-white/10 bg-white">
              <img
                src={dashboardHero.url}
                alt="HK Tech studio dashboard showing Business Overview with Total Revenue, Project Expenses, General Expenses and Net Profit, plus Project Statistics and Financial Summary"
                width={1600}
                height={1000}
                className="h-auto w-full"
              />
            </div>
          </div>
        </div>
      </div>
      <div aria-hidden className="h-16 bg-gradient-to-b from-transparent to-background" />
    </section>
  );
}

function FloatingChip({
  className = "",
  icon: Icon,
  label,
  value,
  tone,
}: {
  className?: string;
  icon: React.ElementType;
  label: string;
  value: string;
  tone: "up" | "brand" | "neutral";
}) {
  const toneClass =
    tone === "brand"
      ? "bg-brand text-brand-foreground border-transparent"
      : tone === "up"
      ? "bg-white text-foreground border-border"
      : "bg-ink text-ink-foreground border-white/10";
  return (
    <div
      className={`absolute z-10 hidden items-center gap-3 rounded-2xl border px-4 py-3 shadow-xl backdrop-blur animate-float-soft sm:flex ${toneClass} ${className}`}
    >
      <div className="grid size-9 place-items-center rounded-xl bg-black/5">
        <Icon className="size-4" />
      </div>
      <div className="text-left">
        <div className="text-[10px] uppercase tracking-widest opacity-70">{label}</div>
        <div className="font-display text-base font-semibold leading-none">{value}</div>
      </div>
    </div>
  );
}

/* ---------- LOGOS ---------- */
function LogosStrip() {
  const items = ["Studio Nord", "Casa Verde", "Atelier 09", "Formae", "Larkspur", "Brutello"];
  return (
    <section className="border-b border-border/60 bg-surface-2/50 py-10">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-center gap-x-12 gap-y-4 px-6">
        <p className="text-xs uppercase tracking-widest text-muted-foreground">
          Built with studios in Mumbai, Delhi &amp; Bengaluru
        </p>
        <div className="flex flex-wrap items-center justify-center gap-x-10 gap-y-3">
          {items.map((n) => (
            <span
              key={n}
              className="font-display text-sm font-medium tracking-tight text-foreground/60"
            >
              {n}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- FEATURES (real modules from the dashboard) ---------- */
function Features() {
  return (
    <section id="features" className="mx-auto max-w-7xl px-6 py-24 sm:py-32">
      <div className="mx-auto max-w-2xl text-center">
        <p className="text-xs uppercase tracking-widest text-brand">Every module of the studio</p>
        <h2 className="mt-3 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
          Built around how design studios actually run
        </h2>
        <p className="mt-4 text-muted-foreground">
          From the first inquiry to net profit — every module of your practice lives in one
          coherent workspace.
        </p>
      </div>

      {/* Bento */}
      <div className="mt-16 grid grid-cols-1 gap-4 md:grid-cols-6 md:auto-rows-fr">
        {/* Business Overview — large */}
        <FeatureCard className="md:col-span-4 md:row-span-2 flex-col justify-between">
          <div>
            <FeatureIcon icon={LayoutDashboard} />
            <h3 className="mt-6 font-display text-2xl font-semibold">Business Overview</h3>
            <p className="mt-2 max-w-md text-sm text-muted-foreground">
              A single dashboard tying Total Revenue, Project Expenses, General Expenses and Net
              Profit to real project activity — updated live as your studio operates.
            </p>
          </div>
          <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label="Total Revenue" value="₹1.73 Cr" trend="+12.4%" />
            <Stat label="Project Expenses" value="₹98.2 L" trend="+8.1%" tone="warn" />
            <Stat label="General Expenses" value="₹32.6 L" trend="+3.2%" tone="warn" />
            <Stat label="Net Profit" value="₹42.1 L" trend="+18.7%" />
          </div>
        </FeatureCard>

        {/* Project Statistics */}
        <FeatureCard className="md:col-span-2">
          <FeatureIcon icon={BarChart3} />
          <h3 className="mt-4 font-display text-xl font-semibold">Project Statistics</h3>
          <p className="mt-2 text-sm text-muted-foreground">
            Track Turnkey and Consultation projects separately — see stage, timeline and margin
            at a glance.
          </p>
          <div className="mt-5 space-y-3">
            <SegmentBar label="Turnkey" value={11} total={16} />
            <SegmentBar label="Consultation" value={5} total={16} tone="alt" />
          </div>
        </FeatureCard>

        {/* Financial Summary */}
        <FeatureCard className="md:col-span-2">
          <FeatureIcon icon={Wallet} />
          <h3 className="mt-4 font-display text-xl font-semibold">Financial Summary</h3>
          <p className="mt-2 text-sm text-muted-foreground">
            Revenue vs. expenses, month by month — with drilldowns into every invoice and bill.
          </p>
          <MiniChart />
        </FeatureCard>
      </div>

      {/* Row 2 */}
      <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-3">
        <FeatureCard>
          <FeatureIcon icon={Users} />
          <h3 className="mt-4 font-display text-xl font-semibold">Projects</h3>
          <p className="mt-2 text-sm text-muted-foreground">
            Manage every turnkey and consultation project with client, scope, milestones,
            purchase orders and payments in one place.
          </p>
        </FeatureCard>
        <FeatureCard>
          <FeatureIcon icon={Building2} />
          <h3 className="mt-4 font-display text-xl font-semibold">Agency</h3>
          <p className="mt-2 text-sm text-muted-foreground">
            Partner agencies, contractors and vendors with their contact books, rate cards and
            outstanding payments.
          </p>
        </FeatureCard>
        <FeatureCard>
          <FeatureIcon icon={UserCog} />
          <h3 className="mt-4 font-display text-xl font-semibold">Staff &amp; Profit Sharing</h3>
          <p className="mt-2 text-sm text-muted-foreground">
            In-house team, roles and per-project profit-sharing — calculated automatically as
            projects close.
          </p>
        </FeatureCard>
      </div>

      {/* Row 3 */}
      <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-3">
        <FeatureCard>
          <FeatureIcon icon={Receipt} />
          <h3 className="mt-4 font-display text-xl font-semibold">Expenses &amp; Bills</h3>
          <p className="mt-2 text-sm text-muted-foreground">
            Project and general expenses captured against the right cost centre so margins
            stay honest.
          </p>
        </FeatureCard>
        <FeatureCard>
          <FeatureIcon icon={ListChecks} />
          <h3 className="mt-4 font-display text-xl font-semibold">Quick Overview</h3>
          <p className="mt-2 text-sm text-muted-foreground">
            A live activity list — today's follow-ups, approvals, pending payments and open
            tasks across the studio.
          </p>
        </FeatureCard>
        <FeatureCard>
          <FeatureIcon icon={ShieldCheck} />
          <h3 className="mt-4 font-display text-xl font-semibold">Roles &amp; Access</h3>
          <p className="mt-2 text-sm text-muted-foreground">
            Sensitive financials stay visible only to the people you choose, with granular
            role-based access.
          </p>
        </FeatureCard>
      </div>
    </section>
  );
}

function Stat({
  label,
  value,
  trend,
  tone = "up",
}: {
  label: string;
  value: string;
  trend: string;
  tone?: "up" | "warn";
}) {
  return (
    <div className="rounded-xl border border-border bg-background p-3">
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      <div className="mt-1 font-display text-lg font-semibold">{value}</div>
      <div
        className={`mt-0.5 text-[11px] font-medium ${
          tone === "up" ? "text-brand" : "text-amber-600"
        }`}
      >
        {trend}
      </div>
    </div>
  );
}

function SegmentBar({
  label,
  value,
  total,
  tone = "brand",
}: {
  label: string;
  value: number;
  total: number;
  tone?: "brand" | "alt";
}) {
  const pct = Math.round((value / total) * 100);
  return (
    <div>
      <div className="flex items-center justify-between text-xs">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-semibold">{value} projects</span>
      </div>
      <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-surface-2">
        <div
          className={`h-full rounded-full ${tone === "brand" ? "bg-brand" : "bg-foreground/70"}`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

function MiniChart() {
  const bars = [42, 55, 48, 68, 61, 78, 72, 88];
  const max = Math.max(...bars);
  return (
    <div className="mt-5 flex h-24 items-end gap-1.5">
      {bars.map((b, i) => (
        <div
          key={i}
          className="flex-1 rounded-t-md bg-gradient-to-t from-brand/30 to-brand"
          style={{ height: `${(b / max) * 100}%` }}
          aria-hidden
        />
      ))}
    </div>
  );
}

function FeatureCard({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`group relative flex overflow-hidden rounded-3xl border border-border bg-surface p-8 transition-all hover:-translate-y-0.5 card-soft ${className}`}
    >
      <div className="relative flex w-full flex-col">{children}</div>
    </div>
  );
}

function FeatureIcon({ icon: Icon }: { icon: React.ElementType }) {
  return (
    <div className="grid size-10 place-items-center rounded-xl border border-brand/20 bg-accent text-brand">
      <Icon className="size-5" />
    </div>
  );
}

/* ---------- WORKFLOW ---------- */
function Showcase() {
  const steps = [
    {
      n: "01",
      title: "Capture the project",
      body: "Log every new turnkey or consultation project with client, scope and budget in a single form.",
    },
    {
      n: "02",
      title: "Run the studio",
      body: "Assign staff and agencies, record expenses, track payments and update milestones as work happens.",
    },
    {
      n: "03",
      title: "See the numbers",
      body: "Business Overview and Financial Summary keep revenue, expenses and net profit visible in real time.",
    },
  ];
  return (
    <section id="workflow" className="relative border-y border-border bg-surface-2/50 py-24 sm:py-32">
      <div aria-hidden className="pointer-events-none absolute inset-0 bg-grid-paper opacity-40" />
      <div className="relative mx-auto max-w-7xl px-6">
        <div className="grid gap-16 lg:grid-cols-2 lg:items-center">
          <div>
            <p className="text-xs uppercase tracking-widest text-brand">The HK Tech way</p>
            <h2 className="mt-3 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
              From first project to real profit
            </h2>
            <p className="mt-4 max-w-lg text-muted-foreground">
              A single, coherent workflow that follows how design studios actually operate —
              not a generic sales CRM bolted on top of your practice.
            </p>
            <ul className="mt-10 space-y-6">
              {steps.map((s) => (
                <li key={s.n} className="flex gap-5">
                  <div className="font-display text-sm font-semibold text-brand">{s.n}</div>
                  <div>
                    <h3 className="font-display text-lg font-semibold">{s.title}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{s.body}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
          <div className="relative">
            <div
              aria-hidden
              className="absolute -inset-4 -z-10 rounded-[2rem] bg-[radial-gradient(50%_50%_at_50%_50%,color-mix(in_oklab,var(--brand)_18%,transparent)_0%,transparent_70%)] blur-2xl"
            />
            <div className="overflow-hidden rounded-3xl border border-border bg-surface card-soft">
              <img
                src={dashboardHero.url}
                alt="HK Tech studio dashboard preview"
                loading="lazy"
                width={1600}
                height={1000}
                className="h-auto w-full"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- TESTIMONIALS ---------- */
function Testimonials() {
  return (
    <section id="testimonials" className="mx-auto max-w-7xl px-6 py-24 sm:py-32">
      <div className="mx-auto max-w-2xl text-center">
        <p className="text-xs uppercase tracking-widest text-brand">Loved by studios</p>
        <h2 className="mt-3 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
          Studios shipping better work, faster
        </h2>
        <p className="mt-4 text-muted-foreground">
          Rated 4.9/5 by interior design practices across India.
        </p>
      </div>
      <div className="mt-14 grid gap-6 md:grid-cols-3">
        {TESTIMONIALS.map((t) => (
          <figure
            key={t.name}
            className="flex flex-col justify-between rounded-3xl border border-border bg-surface p-8 card-soft"
          >
            <div>
              <div className="flex gap-0.5 text-brand" aria-label="5 out of 5 stars">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="size-4 fill-current" />
                ))}
              </div>
              <blockquote className="mt-5 font-display text-lg leading-snug text-foreground">
                “{t.quote}”
              </blockquote>
            </div>
            <figcaption className="mt-8 flex items-center gap-3">
              <div className="grid size-10 place-items-center rounded-full bg-accent font-display text-sm font-semibold text-brand">
                {t.name.split(" ").map((n) => n[0]).join("")}
              </div>
              <div>
                <div className="text-sm font-semibold">{t.name}</div>
                <div className="text-xs text-muted-foreground">{t.role}</div>
              </div>
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
}

/* ---------- FAQ ---------- */
function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="mx-auto max-w-4xl px-6 py-24 sm:py-32">
      <div className="mx-auto max-w-2xl text-center">
        <p className="text-xs uppercase tracking-widest text-brand">FAQ</p>
        <h2 className="mt-3 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
          Questions, answered
        </h2>
        <p className="mt-4 text-muted-foreground">
          Everything you need to know before starting your free trial.
        </p>
      </div>
      <div className="mt-12 divide-y divide-border overflow-hidden rounded-3xl border border-border bg-surface card-soft">
        {FAQS.map((f, i) => {
          const isOpen = open === i;
          return (
            <div key={f.q}>
              <button
                onClick={() => setOpen(isOpen ? null : i)}
                className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left transition-colors hover:bg-surface-2"
                aria-expanded={isOpen}
              >
                <span className="font-display text-base font-semibold">{f.q}</span>
                <span className="grid size-8 shrink-0 place-items-center rounded-full border border-border bg-surface text-brand">
                  {isOpen ? <Minus className="size-4" /> : <Plus className="size-4" />}
                </span>
              </button>
              {isOpen && (
                <div className="px-6 pb-6 text-sm leading-relaxed text-muted-foreground">
                  {f.a}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}

/* ---------- CTA ---------- */
function CTA() {
  return (
    <section className="mx-auto max-w-7xl px-6 pb-24 sm:pb-32">
      <div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-ink p-12 text-center text-ink-foreground sm:p-20">
        <div
          aria-hidden
          className="absolute inset-0 -z-10 bg-[radial-gradient(50%_60%_at_50%_100%,color-mix(in_oklab,var(--brand)_30%,transparent)_0%,transparent_70%)]"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 -z-10 opacity-[0.08]"
          style={{
            backgroundImage:
              "linear-gradient(to right, #fff 1px, transparent 1px), linear-gradient(to bottom, #fff 1px, transparent 1px)",
            backgroundSize: "48px 48px",
            maskImage: "radial-gradient(ellipse at center, black 40%, transparent 75%)",
          }}
        />
        <h2 className="mx-auto max-w-2xl font-display text-4xl font-semibold tracking-tight sm:text-5xl">
          Run your studio, not your spreadsheets
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-white/70">
          Join the design practices building their next chapter on HK Tech.
        </p>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <a
            href="https://portal.hktech.in/"
            className="inline-flex items-center gap-1 rounded-full bg-brand px-6 py-3 text-sm font-semibold text-brand-foreground transition-transform hover:scale-[1.02]"
          >
            Try it free <ArrowUpRight className="size-4" />
          </a>
          <a
            href="#features"
            className="inline-flex items-center rounded-full border border-white/20 bg-white/5 px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-white/10"
          >
            Explore features
          </a>
        </div>
      </div>
    </section>
  );
}

/* ---------- FOOTER ---------- */
function Footer() {
  return (
    <footer className="border-t border-border py-12">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 px-6 sm:flex-row">
        <div className="flex items-center gap-2">
          <div className="grid size-7 place-items-center rounded-md bg-brand text-brand-foreground">
            <span className="font-display text-xs font-bold">HK</span>
          </div>
          <span className="font-display text-sm font-semibold">HK Tech</span>
          <span className="text-xs text-muted-foreground">© 2026</span>
        </div>
        <nav className="flex flex-wrap justify-center gap-6 text-sm text-muted-foreground">
          <a href="#features" className="hover:text-foreground">Features</a>
          <a href="#workflow" className="hover:text-foreground">Workflow</a>
          <a href="#testimonials" className="hover:text-foreground">Testimonials</a>
          <a href="#faq" className="hover:text-foreground">FAQ</a>
          <a href="https://portal.hktech.in/" className="hover:text-foreground">Log in</a>
        </nav>
      </div>
    </footer>
  );
}
